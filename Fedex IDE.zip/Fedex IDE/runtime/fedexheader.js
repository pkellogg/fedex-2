<template id="fedexheader"> <!--all inside #shadow-dom-->
 
<header class="fxheaderclass"> <!--never absolute-->
<link rel="stylesheet" href="headerstyle.css">
<slot name="header-image"></slot>
<slot name="element-name"></slot>
<slot name="element-name2"></slot> 
<slot name="button-slot"></slot>
 
</header>
</template>

<script>
customElements.define('fedex-header', class extends HTMLElement {   
static get observedAttributes() {return ['width', 'height', 'c', 'layer', 'trans' ]; }
constructor() {
      super(); 
	  let shadowRoot = this.attachShadow({mode: 'open'});  
	  shadowRoot.appendChild(fedexheader.content.cloneNode(true));
	  
	  var style = document.createElement('style'); 
      shadowRoot.appendChild(style);
	  
	  var picture = document.createElement('picture'); 
      shadowRoot.appendChild(picture);
} //constructor
connectedCallback() {
updateStyleHeader(this);   
}   
attributeChangedCallback(name, oldValue, newValue) {updateStyleHeader(this);}
})

function updateStyleHeader(elem) {   //each updateStyle function must be unique as in updateStyleHeader
  var shadow = elem.shadowRoot;
  var childNodes = shadow.childNodes;
  for(var i = 0; i < childNodes.length; i++) {
    if(childNodes[i].nodeName === 'STYLE') {   //building the inline element style
      childNodes[i].textContent = '.fxheaderclass {' +
						  ' width: ' + elem.getAttribute('width') + 'px;' +     
                          ' height: ' + elem.getAttribute('height') + 'px;' +
                          ' background-color: ' + elem.getAttribute('c') + ';' +  
						  ' z-index: ' + elem.getAttribute('layer') + ';' +  
						  ' opacity: ' + elem.getAttribute('trans') + ';' + '}'						  
	}
	 
	} //for
} //updateStyle
</script>