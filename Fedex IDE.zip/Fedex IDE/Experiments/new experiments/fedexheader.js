﻿let happyThingTemplate = document.createElement('template');
happyThingTemplate.innerHTML = getTemplateString();
 

// Define the element prototype.
class HappyThing extends HTMLElement {
  constructor() {
    super();
    let shadowRoot = this.attachShadow({mode: 'open'});
    this.shadowRoot.appendChild(document.importNode(happyThingTemplate.content, true));
  }
window.customElements.define('fedex-header', HappyThing);

function getTemplateString() {
  return `
<header class="fxheaderclass">  
<link rel="stylesheet" href="headerstyle.css">
<slot name="header-image"></slot>
<slot  name="element-name"></slot>
<slot name="element-name2"></slot> 
<slot name="button-slot"></slot>
<slot></slot> 
</header>
`
}
}