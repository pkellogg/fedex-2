// Create a class for the element
class Square extends HTMLElement {
  // Specify observed attributes so that
  // attributeChangedCallback will work
  static get observedAttributes() {return ['w', 'l']; }

  constructor() {
    // Always call super first in constructor
    super();

    var shadow = this.attachShadow({mode: 'open'});
//you can create a complex component by adding in many different elements.
    var div = document.createElement('div'); //div is the square and is built in the update function
    var style = document.createElement('style'); //need a style node in the update function to build the inline style
    shadow.appendChild(style);
    shadow.appendChild(div);
  }

  connectedCallback() {
    console.log('Custom square element added to page.');
    updateStyle(this);
  }

   attributeChangedCallback(name, oldValue, newValue) {
    console.log('Custom square element attributes changed.');
    updateStyle(this);
  }
}

customElements.define('custom-square', Square);

//this builds the element on the page as a series of dom nodes
function updateStyle(elem) {
  var shadow = elem.shadowRoot;
  var childNodes = shadow.childNodes;
  for(var i = 0; i < childNodes.length; i++) {
    if(childNodes[i].nodeName === 'STYLE') {   //building the inline element style
      childNodes[i].textContent = 'div {' +
                          ' width: ' + elem.getAttribute('l') + 'px;' +    //attributes defined on add or radom buttons
                          ' height: ' + elem.getAttribute('l') + 'px;' +
                          ' background-color: ' + elem.getAttribute('c');
    }
  }
}

 // Create a custom square element
  square = document.createElement('custom-square');
  square.setAttribute('l','200');   //hook up setAttribute commands to the design system property box.
  square.setAttribute('c','green');
  document.body.appendChild(square);

   

 