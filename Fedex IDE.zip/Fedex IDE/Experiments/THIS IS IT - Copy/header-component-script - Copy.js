<!DOCTYPE html>
<html lang="en">
<head>
<title>FedEx XD Web Component IDE</title>
<link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:300,400,500,700" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1.0"> <!--google material  to render corrrectly in mobile-->
   
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<!--color picker see: https://bgrins.github.io/spectrum/#events-change  and   http://jsfiddle.net/bgrins/ctkY3/-->
  
<!--javascript-->

<script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script><script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="material.js"></script>
<script src="ds-ide-V103.js"></script><!--jquery MUST COME FIRST-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>
<!--<script src="//storage.googleapis.com/code.getmdl.io/1.0.1/material.min.js"></script>-->

<!--CSS-->
<link rel="stylesheet" href="Design-System-IDE.css"/>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css"/>
<link rel="stylesheet" href="material.css"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

<!--leaderboard   Circles and Goggle Charts-->
<script src="circles.min.js"></script> <!--this has to be external of the template-->
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script><!--this needs to be external-->

<!--color pick dialog-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/spectrum/1.8.0/spectrum.min.css">

<!--web components polyfill works with ie 11-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcomponentsjs/1.1.0/webcomponents-lite.js"></script>
</head>

<body>   
<!----------------------------------------------------COMPONENTS--------------->
<!--NOTE: the style for the component must be included in the template for the component and the componenet
itself must have a matching class-->

<!--HEADER-->
<template id="fedexheader"> <!--all inside #shadow-dom-->

<link rel="stylesheet" href="headerstyle.css"> 

<header class="fxheaderclass"> <!--never absolute-->
<link rel="stylesheet" href="headerstyle.css">
<slot name="header-image"></slot>
<slot  name="element-name"></slot>
<slot name="element-name2"></slot> 
<slot name="button-slot"></slot>
<slot></slot> 
</header>


</template>
<!--Create custom element and attach to shadow dom-->
<script>
customElements.define('fedex-header', class extends HTMLElement {   
static get observedAttributes() {return ['position' , 'width', 'height', 'c' ]; }
constructor() {
      super(); 
	  let shadowRoot = this.attachShadow({mode: 'open'});  
	  shadowRoot.appendChild(fedexheader.content.cloneNode(true));
	  var style = document.createElement('style'); 
      shadowRoot.appendChild(style);
} //constructor
connectedCallback() {updateStyle(this);document.getElementById("btn1").click();}  //clicks the property dialog ok button to refresh the new copy of the element in drag and drop
attributeChangedCallback(name, oldValue, newValue) {updateStyle(this);}
})

function updateStyle(elem) {
  var shadow = elem.shadowRoot;
  var childNodes = shadow.childNodes;
  for(var i = 0; i < childNodes.length; i++) {
    if(childNodes[i].nodeName === 'STYLE') {   //building the inline element style
      childNodes[i].textContent = '.fxheaderclass {' +
						  'position: ' + elem.getAttribute('position') + ';' + //this order must match observedAttriobutes order
                          ' width: ' + elem.getAttribute('width') + 'px;' +     
                          ' height: ' + elem.getAttribute('height') + 'px;' +
                          ' background-color: ' + elem.getAttribute('c') + ';' + '}' 
	}
  }
}//updateStyle
</script>

<!--END HEADER-->
</body>
</html>
   

 