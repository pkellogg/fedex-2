let tmpl = document.querySelector('#fedexheader');
customElements.define('fedex-header', class extends HTMLElement {
    constructor() {
      super();  
      let shadowRoot = this.attachShadow({mode: 'open'});
      shadowRoot.appendChild(tmpl.content.cloneNode(true));
    }
});